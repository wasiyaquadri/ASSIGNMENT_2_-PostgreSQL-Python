import psycopg2

conn = psycopg2.connect(dbname="postgres", user="postgres", password="wasiya95", host="localhost", port="5432")
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS employee(
        Name TEXT,
        ID INT,
        Age INT
    )
''')
print('Table created successfully')
conn.commit()
cursor.close()
conn.close()

# Insert data
def data():
    conn = psycopg2.connect(dbname="postgres", user="postgres", password="wasiya95", host="localhost", port="5432") 
    cursor = conn.cursor()             
    name = input('Enter name: ')
    id = input('Enter id: ')
    age = input('Enter age: ')

    query ='''insert into employee(Name,ID,Age)values(%s,%s,%s);'''
    cursor.execute(query,(name,id,age))
    print('data added successfully')
    
    
    conn.commit()
    cursor.close()
    conn.close()

data()

